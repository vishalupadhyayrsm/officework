<?php
if (!defined('HOSTNAME')) define("HOSTNAME", 'localhost');
if (!defined('USERNAME')) define("USERNAME", 'asimtllw_attendence');
if (!defined('PASSWORD')) define("PASSWORD", 'attendence@123');
if (!defined('DB')) define("DB", 'asimtllw_attendence');
