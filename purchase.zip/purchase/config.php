<?php
if (!defined('HOSTNAME')) define("HOSTNAME", 'localhost');
if (!defined('USERNAME')) define("USERNAME", 'root');
if (!defined('PASSWORD')) define("PASSWORD", '');
if (!defined('DB')) define("DB", 'attendence');
if (!defined('mail_host')) define("mail_host", "mail.miphub.in");
if (!defined('mail_username')) define("mail_username", "admin@miphub.in");
if (!defined('mail_password')) define("mail_password", "Adminmiphub@123");
if (!defined('domain_name')) define("domain_name", "https://miphub.in/");
