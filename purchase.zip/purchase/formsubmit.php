<?php
session_start();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

include_once("dbconfig.php");
include_once("api.php");

// Retrieve the request endpoint
$uri = explode("/", $_SERVER["REQUEST_URI"]);
$apidata = $uri[3];
$endpoint = $uri[4];
// echo $endpoint;
$result = array();
switch ($endpoint) {
    case "invoice":
        $stmt = $conn->prepare("SELECT * FROM `invoice`");
        // $stmt->bindParam(':sid', $sid);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // print_r($result);
        echo json_encode($result);
        // foreach ($result as $row) {
        //     // Access fields like $row['cid'] and $row['sid']
        //     echo "CID: " . $row['cid'] . ", SID: " . $row['sid'] . "<br>";
        // }
        break;



    default:
        break;
}
